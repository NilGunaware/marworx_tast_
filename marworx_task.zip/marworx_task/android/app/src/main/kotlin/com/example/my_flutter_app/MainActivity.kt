package com.example.akjobportal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
