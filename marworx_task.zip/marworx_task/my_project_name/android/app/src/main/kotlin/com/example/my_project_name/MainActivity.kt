package com.example.my_project_name

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
